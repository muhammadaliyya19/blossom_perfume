        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="text-center">
            SELAMAT DATANG DI SISTEM MANAJEMEN PENJUALAN DAN PREDIKSI BLOSSOM PARFUME CABANG <?=$outlet['alamat_outlet']; ?>
          </h1>
          <div class="row mb-3">
            <img style="width: 100%; height: auto;" src="<?php echo base_url('assets/img/') . 'Logo.png'; ?>" alt="">
          </div>
        
      </div>
    </div>
      <!-- End of Main Content -->