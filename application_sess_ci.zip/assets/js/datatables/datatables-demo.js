// Call the dataTables jQuery plugin
$(document).ready(function () {
  $('#dataTable').DataTable();
  $('#dataTableTeam').DataTable();
  $('#dataTableEmp').DataTable();
  $('#dataTablePm').DataTable();
});
